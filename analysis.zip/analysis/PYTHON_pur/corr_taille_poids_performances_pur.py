from collections import defaultdict, Counter
import math


# Fonction de corrélation de Pearson
def corr(x, y):
    n = len(x)
    if n < 2:
        return 0.0
    mean_x = sum(x) / n
    mean_y = sum(y) / n
    num = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n))
    den_x = math.sqrt(sum((x[i] - mean_x) ** 2 for i in range(n)))
    den_y = math.sqrt(sum((y[i] - mean_y) ** 2 for i in range(n)))
    return num / (den_x * den_y) if den_x and den_y else 0.0

# Fonction principale


def corr_taille_poids_performances(data):
    """
    Analyse la corrélation entre la taille, le poids et 
    le nombre de médailles des athlètes pour chaque sport.

    Cette fonction effectue plusieurs étapes :
    1. Filtrage des athlètes ayant des valeurs valides de taille et de poids.
    2. Calcul du nombre de médailles uniques par athlète (en évitant
     les doublons par épreuve).
    3. Moyenne de la taille et du poids de chaque athlète, et identification
     de son sport principal.
    4. Groupement des athlètes par sport.
    5. Calcul des corrélations absolues de Pearson entre :
        - la taille moyenne et le nombre de médailles
        - le poids moyen et le nombre de médailles
    6. Retourne les sports triés selon la somme des corrélations taille+poids
     décroissante.

    Paramètres
    ----------
    data : list[dict]
        Liste de dictionnaires représentant les athlètes.
        Chaque dictionnaire doit contenir
        au minimum les clés suivantes : 
        'Name', 'Height', 'Weight', 'Medal', 'Sport', 'Event'.

    Retourne
    --------
    list[dict]"""

    # 1. Filtrer les athlètes avec taille et poids valides
    filtered = [row for row in data if row.get(
        'Height') is not None and row.get('Weight') is not None]

    # 2. Compter les médailles uniques par athlète (évite les doublons)
    medals = defaultdict(set)
    for row in filtered:
        if row.get('Medal') is not None:
            medals[row['Name']].add((row.get('Event'), row.get('Medal'))) 

    medal_count = {name: len(event_set) for name, event_set in medals.items()}

    # 3. Moyenne taille/poids par athlète et sport principal
    athlete_info = defaultdict(list)
    for row in filtered:
        athlete_info[row['Name']].append(row)

    athlete_data = []
    for name, rows in athlete_info.items():
        heights = [r['Height'] for r in rows]
        weights = [r['Weight'] for r in rows]
        sports = [r['Sport'] for r in rows]
        sport_counts = Counter(sports)
        most_common_sport = sport_counts.most_common(1)[0][0]

        athlete_data.append({
            'Name': name,
            'Height': sum(heights) / len(heights),
            'Weight': sum(weights) / len(weights),
            'Num_Medals': medal_count.get(name, 0),
            'Sport': most_common_sport
        })

    # 4. Grouper par sport
    sport_groups = defaultdict(list)
    for athlete in athlete_data:
        sport_groups[athlete['Sport']].append(athlete)

    # 5. Calculer les corrélations
    results = []
    for sport, athletes in sport_groups.items():
        if len(athletes) < 10:
            continue
        medals_list = [a['Num_Medals'] for a in athletes]
        if len(set(medals_list)) < 2:
            continue
        heights = [a['Height'] for a in athletes]
        weights = [a['Weight'] for a in athletes]

        corr_height = abs(corr(heights, medals_list))
        corr_weight = abs(corr(weights, medals_list))
        combined = corr_height + corr_weight

        results.append({
            'Sport': sport,
            'Corr_Height': corr_height,
            'Corr_Weight': corr_weight,
            'Combined': combined
        })

    # 6. Trier les résultats par score combiné décroissant
    results.sort(key=lambda x: x['Combined'], reverse=True)
    return results