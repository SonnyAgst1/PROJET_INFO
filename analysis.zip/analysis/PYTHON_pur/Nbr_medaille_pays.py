import pandas as pd


def moyenne_medailles_par_pays_details(data):
    """
    Calcule la moyenne de médailles par pays par année,
    séparée pour sports individuels, collectifs et en total.

    Paramètre :
    - data : liste de dictionnaires ou DataFrame

    Retour :
    - Dictionnaire : {pays: {"individuel": x, "collectif": y, "total": z}, ...}
    """

    # Conversion en DataFrame si besoin
    if isinstance(data, list):
        df = pd.DataFrame(data)
    else:
        df = data.copy()

    # Liste des sports collectifs
    collective_sports = [
        'Basketball', 'Football', 'Handball', 'Hockey', 'Water Polo',
        'Rugby Sevens', 'Baseball', 'Softball', 'Volleyball'
    ]

    # Ajouter catégorie sport
    df['Sport_category'] = df['Sport'].apply(
        lambda x: 'collectif' if x in collective_sports else 'individuel'
    )

    # Supprimer les lignes sans médaille
    medals_df = df.dropna(subset=['Medal'])

    # Collectif : enlever doublons
    coll_medals_unique = medals_df[
        medals_df['Sport_category'] == 'collectif'].drop_duplicates(
        subset=['Team', 'Year', 'Event', 'Medal']
    )

    # Individuel
    indiv_medals = medals_df[medals_df['Sport_category'] == 'individuel']

    # Groupe par Team et Year, puis compte
    indiv_counts = indiv_medals.groupby(
        ['Team', 'Year']).size().reset_index(name='nb_medailles_indiv')
    coll_counts = coll_medals_unique.groupby(
        ['Team', 'Year']).size().reset_index(name='nb_medailles_coll')

    # Fusionner sur Team et Year
    merged = pd.merge(
        indiv_counts, coll_counts, on=['Team', 'Year'], how='outer').fillna(0)

    # Calcul du total
    merged['nb_medailles_total'] = merged[
        'nb_medailles_indiv'] + merged['nb_medailles_coll']

    # Moyenne par pays
    resultats = {}
    for team, group in merged.groupby('Team'):
        resultats[team] = {
            "individuel": group['nb_medailles_indiv'].mean(),
            "collectif": group['nb_medailles_coll'].mean(),
            "total": group['nb_medailles_total'].mean()
        }

    return resultats
