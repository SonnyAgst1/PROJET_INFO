
import csv
import os


def importdonneespur(chemin_relatif):
    base_path = os.path.dirname(__file__)
    full_path = os.path.abspath(os.path.join(base_path, "..", chemin_relatif))

    with open(full_path, newline='', encoding="utf-8") as f:
        reader = csv.DictReader(f)
        data = list(reader)
    return data
