
import pandas as pd
import os


def importdonneepanda(relative_path):
    base_path = os.path.dirname(__file__)  # chemin du fichier python actuel
    full_path = os.path.join(base_path, "..", relative_path)  # remonte d’un 
    # niveau et ajoute le chemin relatif
    full_path = os.path.abspath(full_path)  # convertit en chemin absolu
    return pd.read_csv(full_path)
